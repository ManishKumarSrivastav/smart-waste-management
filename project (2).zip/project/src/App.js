import React,{useState} from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Navbar from './Navbar';
import Home from './components/Home';
import About from './components/About';
import Login from './components/Login';
import RegistrationPage from './components/Rgisterpage';
import TableComponent from './components/admintable';
import ComplaintForm from './complaintpage';
import './CssFiles/Navbar.css';
import UDashboard from './components/UDashboard';
import AdminDashboard from './adminDashboard';
import TableUserComponent from './userTable';
import ComplaintsPage from './adComplaintHandle';
import DumpingAreaTable from './components/dumpingtable';
import RecyclingAreaTable from './components/recylingtable';

// function RegisterComplaintLink() {
//   const navigate = useNavigate();

//   const handleRegisterComplaintClick = () => {
//     // Check if the user is authenticated
//     const isAuthenticated = false; // Replace with your authentication check

//     if (isAuthenticated) {
//       navigate('/complaint');
//     } else {
//       navigate('/login');
//     }
//   };

//   return (
//     // <button className="btn btn-primary" onClick={handleRegisterComplaintClick}>
//     //   Register Complaint
//     // </button>
//   );
// }

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [token, setToken] = useState(localStorage.getItem('authToken')); // Get token from LocalStorage
  const handleLogout = () => {
    // Clear token and do other necessary logout actions
    setToken(null);
    localStorage.removeItem('authToken');
    setIsLoggedIn(false);
  };
  return (
    <Router>
       <Navbar
        isLoggedIn={isLoggedIn}
        home="Home"
        about="About us"
        soln="Solution"
        contact="Contact"
        signin="Sign in"
        signout="Sign out"
        future="future aspect"
        onLogout={handleLogout} // Pass the logout handler to the Navbar
      />
      <div className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          {/* <Route path="/login" element={<Login />} /> */}
          <Route path="/register" element={<RegistrationPage />} />
          <Route path="/admintable" element={<TableComponent />} />
          <Route path="/about" element={<About />} />
          <Route
          path="/login" 
          element={<Login setToken={setToken} />} // Pass setToken to the Login component
          setIsLoggedIn={setIsLoggedIn} />
        <Route
          path="/complaintpage"
          element={token ? <ComplaintForm /> : <Navigate to="/login" />}
        />
         {/* <Route path="/dashboard" element={<UDashboard setToken={setToken} />} /> */}
         <Route path="/" element={<Login setToken={setToken} />} />
        <Route path="/adminDashboard" element={<AdminDashboard />} isLoggedIn={isLoggedIn}/>
        <Route path="/userDashboard" element={<UDashboard />} isLoggedIn={isLoggedIn}/>
        <Route path="/usertable" element={<TableUserComponent />} />
        <Route path="/handlecomplaint" element={<ComplaintsPage />} />
        <Route path="/dumpingarea" element={<DumpingAreaTable />} />
        <Route path="/recylingarea" element={<RecyclingAreaTable />} />
        {/* <Route path="/handlecomplaint" element={<AdminComplaintsPage />} /> */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
