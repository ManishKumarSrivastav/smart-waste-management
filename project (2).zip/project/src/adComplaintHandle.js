import React, { useState, useEffect } from 'react';

const ComplaintsPage = () => {
    const [complaints, setComplaints] = useState([]);
    
    useEffect(() => {
        // Fetch complaints from the server when the component mounts
        fetchComplaints();
    }, []);

    const fetchComplaints = async () => {
        try {
            const response = await fetch('/complaintspage'); // Change to your server endpoint
            if (response.ok) {
                const data = await response.json();
                setComplaints(data);
                console.log(data);
            } else {
                console.error('Failed to fetch complaints');
            }
        } catch (error) {
            console.error('An error occurred:', error);
        }
    };

    const handleStatusChange = async (complaintID, newStatus) => {
        try {
            const response = await fetch(`/api/complaints/${complaintID}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ status: newStatus }),
            });

            if (response.ok) {
                // Update the local complaints state with the new status
                const updatedComplaints = complaints.map(complaint => {
                    if (complaint.complaintID === complaintID) {
                        return { ...complaint, status: newStatus };
                    }
                    return complaint;
                });
                setComplaints(updatedComplaints);
            } else {
                console.error('Failed to update complaint status');
            }
        } catch (error) {
            console.error('An error occurred:', error);
        }
    };

    return (
        <div>
            <h2>Admin Complaints</h2>
            <table className="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User ID</th>
                        <th>Request Text</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {complaints.map(complaint => (
                        <tr key={complaint.complaintID}>
                            <td>{complaint.complaintID}</td>
                            <td>{complaint.userID}</td>
                            <td>{complaint.requestText}</td>
                            <td>{complaint.status}</td>
                            <td>
                                <button
                                    className="btn btn-sm btn-success"
                                    onClick={() => handleStatusChange(complaint.complaintID, 'approved')}
                                >
                                    Approve
                                </button>
                                <button
                                    className="btn btn-sm btn-info"
                                    onClick={() => handleStatusChange(complaint.complaintID, 'completed')}
                                >
                                    Complete
                                </button>
                                <button
                                    className="btn btn-sm btn-danger"
                                    onClick={() => handleStatusChange(complaint.complaintID, 'rejected')}
                                >
                                    Reject
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ComplaintsPage;
