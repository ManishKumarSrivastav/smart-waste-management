const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const jwt = require('jsonwebtoken');
const crypto=require('crypto');
// const bcrypt = require('bcrypt');
const nodemailer = require('nodemailer'); 
const { google } = require("googleapis");
require("dotenv").config();


const app = express();
const secretKey = '12345'; // Replace with a strong secret key

// Mock user data (you'd normally fetch this from a database)

app.use(cors());
app.use(express.json());


//database connection stablize here //
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'manish94261',
  database: 'wastemanagement'
});

db.connect(err => {
  if (err) {
    console.error('Error connecting to database:', err);
  } else {
    console.log('Connected to database');
  }
});

app.listen(5000, () => {
  console.log('Server is running on port 5000');
});



//login fatching through database credential and jump page to dashboard


app.post('/login', (req, res) => {
  const { email, password, role } = req.body;
  console.log('Received data: email:', email, 'pwd:', password, 'Role:', role);

  const selectQuery = `SELECT * FROM ${role} WHERE email = ?`;
  db.query(selectQuery, [email], (error, results) => {
    if (error) {
      console.error('Error querying the database:', error);
      res.status(500).json({ message: 'Error logging in' });
    } else if (results.length === 0) {
      console.log('User not found:', email);
      res.status(401).json({ message: 'Invalid credentials' });
    } else {
      const user = results[0];
      console.log(user);

     // Convert both passwords to strings before comparison
const storedPasswordString = user.Password.toString('utf-8');
const providedPasswordString = password.toString('utf-8');

// Compare the provided password with the password stored in the database
const passwordMatch = storedPasswordString === providedPasswordString;

      if (!passwordMatch) {
        console.log('Invalid password for user:', email);
        res.status(401).json({ message: 'Invalid credentials' });
      } else {
        console.log('Authentication successful for user:', email);
        // Authentication successful, issue a token
        const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, '12345');
        res.json({ token });//token go in app.js
      }
    }
  });
});




// get admin data from database

app.get('/api/getAdminData', (req, res) => {
  try {
    // Query to get all admin data from the admin table
    db.query('SELECT * FROM admin', (error, results) => {
      if (error) {
        console.error('Error retrieving admin data:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else {
        res.status(200).json(results);
      }
    });
  } catch (error) {
    console.error('Error retrieving admin data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});



//get usesr data from database



app.get('/api/getuserData', (req, res) => {
  try {
    // Query to get all admin data from the admin table
    db.query('SELECT * FROM user', (error, results) => {
      if (error) {
        console.error('Error retrieving admin data:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else {
        res.status(200).json(results);
      }
    });
  } catch (error) {
    console.error('Error retrieving users data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// Endpoint to get complaints
app.get('/api/getComplaints', (req, res) => {
  try {
    // Query to get all admin data from the admin table
    db.query('SELECT * FROM complaints', (error, results) => {
      if (error) {
        console.error('Error retrieving complaints data:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else {
        res.status(200).json(results);
      }
    });
  } catch (error) {
    console.error('Error retrieving complaints data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});




//forwording page on admin and user dashboard

app.get('/dashboard', (req, res) => {
  const token = req.header('Authorization');

  if (!token) {
    res.status(401).json({ message: 'Unauthorized' });
  }

  try {
    const decoded = jwt.verify(token, 'secretKey');
    if (decoded.role === 'admin') {
      res.json({ message: 'Welcome to the admin dashboard' });
    } else {
      res.json({ message: 'Welcome to the user dashboard' });
    }
  } catch (error) {
    res.status(401).json({ message: 'Unauthorized' });
  }
});





//for notification to particular user and admin 

app.post('/complaintpage', (req, res) => {
  const { complaint } = req.body;
  const userEmail = req.user.email; // Assuming user email is available in req.user

  // Fetch userID from the user table based on the userEmail
  const getUserIdQuery = db.query('SELECT userID FROM user WHERE Email = ?');

  db.query(getUserIdQuery, [userEmail], (error, result) => {
    if (error) {
      console.error('Error fetching user ID:', error);
      res.status(500).json({ error: 'Error submitting the complaint.' });
    } else {
      if (result.length === 0) {
        res.status(404).json({ error: 'User not found.' });
      } else {
        const userId = result[0].userID;
        const insertQuery = 'INSERT INTO complaints (userID, requestText, Email, status) VALUES (?, ?, ?, ?)';
        const complaintStatus = 'pending'; // You can set the initial status as per your requirement

        db.query(insertQuery, [userId, complaint, userEmail, complaintStatus], (error, result) => {
          if (error) {
            console.error('Error saving complaint:', error);
            res.status(500).json({ error: 'Error submitting the complaint.' });
          } else {
            // Send notification to user
            sendUserNotification(userEmail, 'Your complaint has been submitted.');

            // Send notification to admin
            sendAdminNotification('admin@example.com', 'New complaint submitted.');

            res.status(200).json({ message: 'Complaint submitted successfully.' });
          }
        });
      }
    }
  });
});







///email sending option for 


const OAuth2 = google.auth.OAuth2;
const oauth2Client = new OAuth2(
  process.env.CLIENT_ID,
  process.env.CLIENT_SECRET,
  "https://developers.google.com/oauthplayground" // Redirect URL
);
oauth2Client.setCredentials({
  refresh_token: process.env.REFRESH_TOKEN,
});

const accessToken = oauth2Client.getAccessToken();

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    type: "OAuth2",
    user: process.env.EMAIL,
    clientId: process.env.CLIENT_ID,
    clientSecret: process.env.CLIENT_SECRET,
    refreshToken: process.env.REFRESH_TOKEN,
    accessToken: accessToken,
  },
});

const mailOptions = {
  from: '"wastemanagement department" <your-email@gmail.com>',
  to: "chhotusrivastava261@gmail.com",
  subject: "Nodemailer API",
  text: "complaint registerd successfully",
};


 transporter.sendMail(mailOptions, (err, data) => {
  if (err) {
    console.log("Error " + err);
   } else {
     console.log("Email sent successfully");
  }
 });

// Endpoint to add data based on role (admin or user)


app.post('/register', (req, res) => {
  const { Role } = req.body;

 

  if (Role === 'admin') {
    const {
      Username,
      Password,
      FirstName,
      LastName,
      Email,
      MobileNumber,
      Address,
      City,
      State,
      Country,
      PostalCode,
      EmployeeCode
    } = req.body;
console.log( Username,
  Password,
  FirstName,
  LastName,
  Email,
  MobileNumber,
  Address,
  City,
  State,
  Country,
  PostalCode,
  EmployeeCode);
    // TODO: Perform necessary data validation and sanitize input here
    
    const insertQuery = `INSERT INTO admin (Employeecode, Username, Password, FirstName, LastName, Email, MobileNumber, Address, City, State, Country, PostalCode)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
                         
   // const adminRole = 'admin'; // Role fixed as 'admin' based on the table structure

    db.query(
        insertQuery,
        [
            EmployeeCode,
            Username,
            Password,
            FirstName,
            LastName,
            Email,
            MobileNumber,
            Address,
            City,
            State,
            Country,
            PostalCode,
        ],
        (err, result) => {
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                res.status(200).json({ message: 'Admin registered successfully' });
            }
        }
    );




    //user credential for 
  } else if (Role === 'user') {
    console.log(req.body);
    const {
      Username,
      Password,
      FirstName,
      LastName,
      Email,
      MobileNumber,
      Address,
      City,
      State,
      Country,
      PostalCode
      
    } = req.body;
    console.log( Username,
      Password,
      FirstName,
      LastName,
      Email,
      MobileNumber,
      Address,
      City,
      State,
      Country,
      PostalCode,
  );

    // TODO: Perform necessary data validation and database insert here
    const insertQuery = `INSERT INTO User (Username, Password, FirstName, LastName, Email, MobileNumber, Address, City, State, Country, PostalCode)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    db.query(
      insertQuery,
      [
        Username,
        Password,
        FirstName,
        LastName,
        Email,
        MobileNumber,
        Address,
        City,
        State,
        Country,
        PostalCode
        
      ],
      (err, result) => {
        if (err) {
          res.status(500).json({ error: err.message });
        } else {
          res.status(200).json({ message: 'User registered successfully' });
        }
      }
    );
  }
});

//add and fetch data from recycle table 
app.get('/api/getRecyclingAreas', (req, res) => {
  try {
    // Query to get all admin data from the admin table
    db.query('SELECT * FROM recycling_area', (error, results) => {
      if (error) {
        console.error('Error retrieving complaints data:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else {
        res.status(200).json(results);
      }
    });
  } catch (error) {
    console.error('Error retrieving complaints data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

;

app.post('/api/addRecyclingArea', async (req, res) => {
  const newRecyclingArea = req.body;

  try {
      const connection = await pool.getConnection();
      const insertQuery = `INSERT INTO recycling_area 
          (location_name, address, city, state, country, postal_code, 
          latitude, longitude, capacity, status, recycling_type)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

      await connection.query(insertQuery, [
          newRecyclingArea.location_name,
          newRecyclingArea.address,
          newRecyclingArea.city,
          newRecyclingArea.state,
          newRecyclingArea.country,
          newRecyclingArea.postal_code,
          newRecyclingArea.latitude,
          newRecyclingArea.longitude,
          newRecyclingArea.capacity,
          newRecyclingArea.status,
          newRecyclingArea.recycling_type,
      ]);

      connection.release();
      res.status(200).json({ message: 'Recycling area added successfully' });
  } catch (error) {
      console.error('Error adding recycling area:', error);
      res.status(500).json({ error: 'An error occurred while adding recycling area' });
  }
});


// add and fetch data from database for dumping table

app.get('/api/getDumpingAreas', (req, res) => {
  try {
    // Query to get all admin data from the admin table
    db.query('SELECT * FROM dumping_area', (error, results) => {
      if (error) {
        console.error('Error retrieving complaints data:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else {
        res.status(200).json(results);
      }
    });
  } catch (error) {
    console.error('Error retrieving complaints data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});



app.post('/api/addDumpingArea', async (req, res) => {
  const newDumpingArea = req.body;

  try {
      const connection = await pool.getConnection();
      const insertQuery = `INSERT INTO dumping_area 
          (location_name, address, city, state, country, postal_code, 
          latitude, longitude, capacity)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

      await connection.query(insertQuery, [
          newDumpingArea.location_name,
          newDumpingArea.address,
          newDumpingArea.city,
          newDumpingArea.state,
          newDumpingArea.country,
          newDumpingArea.postal_code,
          newDumpingArea.latitude,
          newDumpingArea.longitude,
          newDumpingArea.capacity,
      ]);

      connection.release();
      res.status(200).json({ message: 'Dumping area added successfully' });
  } catch (error) {
      console.error('Error adding dumping area:', error);
      res.status(500).json({ error: 'An error occurred while adding dumping area' });
  }
});









app.put('/api/updateData/:id', (req, res) => {
  const { Role } = req.body;
  const id = req.params.id;

  if (Role === 'admin') {
    // Update admin data based on ID
    // ...
  } else if (Role === 'user') {
    // Update user data based on ID
    // ...
  }
});




app.delete('/api/deleteData/:id', (req, res) => {
  const { Role } = req.body;
  const id = req.params.id;

  if (Role === 'admin') {
    // Delete admin data based on ID
    // ...
  } else if (Role === 'user') {
    // Delete user data based on ID
    // ...
  }
});




app.get('/api/getData/:id', (req, res) => {
  const { Role } = req.body;
  const id = req.params.id;

  if (Role === 'admin') {
    // Get admin data based on ID
    // ...
  } else if (Role === 'user') {
    // Get user data based on ID
    // ...
  }
});




app.get('/api/getAllData', (req, res) => {
  const { Role } = req.body;

  if (Role === 'admin') {
    // Get all admin data
    // ...
  } else if (Role === 'user') {
    // Get all user data
    // ...
  }
});




// Endpoint to update data based on role (admin or user)
app.put('/api/updateData/:id', (req, res) => {
  const { Role } = req.body;
  const id = req.params.id;

  if (Role === 'admin') {
    // Admin update logic
    // ...
  } else if (Role === 'user') {
    // Update student data in the database
    // ...
  }
});




// Endpoint to delete data based on role (admin or user)
app.delete('/api/deleteData/:id', (req, res) => {
  const { Role } = req.body;
  const id = req.params.id;

  if (Role === 'admin') {
    // Admin delete logic
    // ...
  } else if (Role === 'user') {
    // Delete student data from the database
    // ...
  }
});




// Endpoint to fetch data based on role (admin or user)
app.get('/api/getData/:Role', (req, res) => {
  const { Role } = req.params;

  if (Role === 'admin') {
    // Fetch admin data from the database
    // ...
  } else if (Role === 'user') {
    // Fetch student data from the database
    const query = 'SELECT * FROM student';
    db.query(query, (err, results) => {
      if (err) {
        res.status(500).json({ error: err.message });
      } else {
        res.status(200).json(results);
      }
    });
  }
});

