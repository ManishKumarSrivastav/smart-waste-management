import React, { useState, useEffect } from 'react';
// import Header from './components/Header';
// import Sidebar from './components/Sidebar';
// import ComplaintsPage from './adComplaintHandle';
import { Link } from "react-router-dom";
import TableUserComponent from './userTable';
import TableComponent from './components/admintable';
import DumpingAreaTable from './components/dumpingtable';
import RecyclingAreaTable from './components/recylingtable';
import ComplaintsTable from './components/complainttable';

const AdminDashboard = () => {
    const [complaints, setComplaints] = useState([]);
    const [activeContent, setActiveContent] = useState(null);
    useEffect(() => {
        const fetchComplaints = async () => {
            try {
                const response = await fetch('http://localhost:5000/api/getComplaints');
                const data = await response.json();
                setComplaints(data);
            } catch (error) {
                console.error('Error fetching complaints:', error);
            }
        };
        fetchComplaints();
    }, []);

    const fetchComplaints = async () => {
        try {
            const response = await fetch('http://localhost:5000/api/getComplaints'); // Replace with your API endpoint
            const data = await response.json();
            setComplaints(data);
        } catch (error) {
            console.error('Error fetching complaints:', error);
        }
    };

    const handleStatusChange = async (complaintId, newStatus) => {
        try {
            // Update the status of the complaint in the server or database
            const response = await fetch(`/api/updateComplaintStatus/${complaintId}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ status: newStatus }),
            });

            if (response.ok) {
                // Update the status locally after successful server update
                const updatedComplaints = complaints.map((complaint) => {
                    if (complaint.id === complaintId) {
                        return { ...complaint, status: newStatus };
                    }
                    return complaint;
                });
                setComplaints(updatedComplaints);

                // Send a notification to the user whose complaint status has changed
                const userResponse = await fetch(`/api/sendNotificationToUser/${complaintId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });

                if (userResponse.ok) {
                    console.log('Notification sent to user');
                }
            }
        } catch (error) {
            console.error('Error updating complaint status:', error);
        }
    };

    return (
        <div className="container-fluid">
            <h2 style={{textAlign:'center'}}>Admin Dashboard</h2>
        <nav className="navbar navbar-light">
            
            <ul style={{ listStyle: 'none' }}>
                <li className="nav-item dropdown">
                    <a
                        className="nav-link dropdown-toggle"
                        href="/"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </a>
                    <ul style={{ listStyle: 'none' }} className="dropdown-menu">
                        <li>
                            {/* Use onClick to set activeContent */}
                            <Link
                                className="dropdown-item"
                                onClick={() => setActiveContent('complaints')}
                                to="#"
                            >
                                complaints
                            </Link>
                        </li>
                        <li>
                            {/* Set activeContent for each link */}
                            <Link
                                className="dropdown-item"
                                onClick={() => setActiveContent('dumpingarea')}
                                to="#"
                            >
                                Dumping Area
                            </Link>
                        </li>
                        <li>
                            {/* Set activeContent for each link */}
                            <Link
                                className="dropdown-item"
                                onClick={() => setActiveContent('recylingarea')}
                                to="#"
                            >
                                Recycling Area
                            </Link>
                        </li>
                        <li>
                            {/* Set activeContent for each link */}
                            <Link
                                className="dropdown-item"
                                onClick={() => setActiveContent('admintable')}
                                to="#"
                            >
                                Admindata
                            </Link>
                        </li>
                        <li>
                            {/* Set activeContent for each link */}
                            <Link
                                className="dropdown-item"
                                onClick={() => setActiveContent('usertable')}
                                to="#"
                            >
                                UserData
                            </Link>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>

        {/* Render different components based on activeContent */}
        {activeContent === 'complaints' && (
            <ComplaintsTable
                complaints={complaints}
                handleStatusChange={handleStatusChange}
            />
        )}
        {activeContent === 'dumpingarea' && <DumpingAreaTable />}
        {activeContent === 'recylingarea' && <RecyclingAreaTable />}
        {activeContent === 'admintable' && <TableComponent />}
        {activeContent === 'usertable' && <TableUserComponent />}
    </div>
);
};

export default AdminDashboard;