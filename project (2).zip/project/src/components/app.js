import React, { useState, useEffect } from 'react';

function App() {
  const [tasks, setTasks] = useState([]);
  
  useEffect(() => {
    fetchTasks();
  }, []);
  
  const fetchTasks = async () => {
    try {
      const response = await fetch('/api/tasks'); // Update with your backend URL
      const data = await response.json();
      setTasks(data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };
  
  const renderTasks = () => {
    return tasks.map(task => (
      <div key={task.id}>
        {task.title}
      </div>
    ));
  };
  
  return (
    <div>
      <h1>Todo List</h1>
      {renderTasks()}
    </div>
  );
}

export default App;
