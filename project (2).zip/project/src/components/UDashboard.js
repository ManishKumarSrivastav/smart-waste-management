import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';


const Dashboard = () => {
  const [userData, setUserData] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserData = async () => {
        const authToken = localStorage.getItem('authToken');
        console.log('authToken:', authToken); // Add this line
        if (!authToken) {
          // Token is not present, user is not authenticated
          // Redirect to sign-in page
          navigate('/login');
        }
    }
      }, []); // Empty dependency array

  const handleUpdateProfile = async () => {
    // Implement update profile functionality here
    // You can use a similar fetch approach as above to send updated data to the server
  };

  return (
    <div className="container mt-5">
      <div className="card">
        <div className="card-body">
          <h2 className="card-title">Welcome to the Dashboard</h2>
          {/* <p className="card-text">Name: {userData.name}</p>
          <p className="card-text">Email: {userData.email}</p>
          <p className="card-text">Role: {userData.role}</p> */}
          {/* Add more user-specific data as needed */}
          <button className="btn btn-primary" onClick={handleUpdateProfile}>
            Update Profile
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
