import React from 'react';
import { Link } from "react-router-dom";
import ComplaintsPage from '../adComplaintHandle';



const Header = () => {
    return (
        <nav className="navbar navbar-light ">
            {/* <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#basic-navbar-nav"> */}
                
                <li className="nav-item dropdown">
                <a
                  className="nav-link dropdown-toggle"
                  href="/"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                 <span className="navbar-toggler-icon"></span>
                </a>
                <ul className="dropdown-menu">
                  <li>
                    <Link className="dropdown-item" to="/handlecomplaint">
                    complaints
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/">
                      Dumping Area
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/">
                      Recycling Area
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/admintable">
                      Admindata
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/usertable">
                      UserData
                    </Link>
                  </li>
                </ul>
            </li>
        </nav>
    );
};

export default Header;
