import React, { useState, useEffect } from 'react';

const DumpingAreaTable = () => {
   
    const [aauthToken, setAuthToken] = useState(null); // Example state to hold admin's auth token

    // Assume you're setting the admin's auth token using some method
    useEffect(() => {
        const adminToken = localStorage.getItem("adminAuthToken"); // Replace with your method to get admin's auth token
        setAuthToken(adminToken);
    }, []);
    const [dumpingAreas, setDumpingAreas] = useState([]);
    const [newDumpingArea, setNewDumpingArea] = useState({
        location_name: '',
        address: '',
        city: '',
        state: '',
        country: '',
        postal_code: '',
        latitude: '',
        longitude: '',
        capacity: '',
    });

    useEffect(() => {
        fetchDumpingAreas();
    }, []);

    const fetchDumpingAreas = async () => {
        try {
            const response = await fetch('http://localhost:5000/api/getDumpingAreas');
            const data = await response.json();
            setDumpingAreas(data);
        } catch (error) {
            console.error('Error fetching dumping areas:', error);
        }
    };

    const handleAddDumpingArea = async () => {
        try {
            const response = await fetch('http://localhost:5000/api/addDumpingArea', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newDumpingArea),
            });

            if (response.ok) {
                const newDumpingAreas = [...dumpingAreas, newDumpingArea];
                setDumpingAreas(newDumpingAreas);
                setNewDumpingArea({
                    location_name: '',
                    address: '',
                    city: '',
                    state: '',
                    country: '',
                    postal_code: '',
                    latitude: '',
                    longitude: '',
                    capacity: '',
                });
            }
        } catch (error) {
            console.error('Error adding dumping area:', error);
        }
    };

    return (
<div>
       
       
  <h2>Dumping Areas</h2>
  <table className="table table-striped table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>Location Name</th>
        <th>Address</th>
        <th>City</th>
        <th>State</th>
        <th>Country</th>
        <th>Postal Code</th>
        <th>Latitude</th>
        <th>Longitude</th>
        <th>Capacity</th>
      </tr>
    </thead>
    <tbody>
      {dumpingAreas.map((dumpingArea) => (
        <tr key={dumpingArea.id}>
          <td>{dumpingArea.id}</td>
          <td>{dumpingArea.location_name}</td>
          <td>{dumpingArea.address}</td>
          <td>{dumpingArea.city}</td>
          <td>{dumpingArea.state}</td>
          <td>{dumpingArea.country}</td>
          <td>{dumpingArea.postal_code}</td>
          <td>{dumpingArea.latitude}</td>
          <td>{dumpingArea.longitude}</td>
          <td>{dumpingArea.capacity}</td>
        </tr>
      ))}
    </tbody>
  </table>

  {aauthToken && (<div >
  <h2>Add New Dumping Area</h2>
  <div>
    <input
      className="form-control"
      type="text"
      placeholder="Location Name"
      value={newDumpingArea.location_name}
      onChange={(e) =>
        setNewDumpingArea({ ...newDumpingArea, location_name: e.target.value })
      }
    />
    <input
      className="form-control"
      type="text"
      placeholder="Address"
      value={newDumpingArea.address}
      onChange={(e) =>
        setNewDumpingArea({ ...newDumpingArea, address: e.target.value })
      }
    />
    <input
      className="form-control"
      type="text"
      placeholder="City"
      value={newDumpingArea.city}
      onChange={(e) =>
        setNewDumpingArea({ ...newDumpingArea, city: e.target.value })
      }
    />
    <input
      className="form-control"
      type="text"
      placeholder="State"
      value={newDumpingArea.state}
      onChange={(e) =>
        setNewDumpingArea({ ...newDumpingArea, state: e.target.value })
      }
    />
    <input
      className="form-control"
      type="text"
      placeholder="Country"
      value={newDumpingArea.country}
      onChange={(e) =>
        setNewDumpingArea({ ...newDumpingArea, country: e.target.value })
      }
    />
    <input
      className="form-control"
      type="text"
      placeholder="Postal Code"
      value={newDumpingArea.postal_code}
      onChange={(e) =>
        setNewDumpingArea({ ...newDumpingArea, postal_code: e.target.value })
      }
    />
    <input
      className="form-control"
      type="number"
      step="0.00000001"
      placeholder="Latitude"
      value={newDumpingArea.latitude}
      onChange={(e) =>
        setNewDumpingArea({ ...newDumpingArea, latitude: e.target.value })
      }
    />
    <input
      className="form-control"
      type="number"
      step="0.00000001"
      placeholder="Longitude"
      value={newDumpingArea.longitude}
      onChange={(e) =>
        setNewDumpingArea({ ...newDumpingArea, longitude: e.target.value })
      }
    />
    <input
      className="form-control"
      type="number"
      placeholder="Capacity"
      value={newDumpingArea.capacity}
      onChange={(e) =>
        setNewDumpingArea({ ...newDumpingArea, capacity: e.target.value })
      }
    />
    <select
      className="form-control"
      value={newDumpingArea.status}
      onChange={(e) =>
        setNewDumpingArea({ ...newDumpingArea, status: e.target.value })
      }
    >
      <option value="active">Active</option>
      <option value="inactive">Inactive</option>
    </select>
    {/* Add similar input fields for latitude, longitude, capacity, status, created_at, and updated_at */}
  </div>
</div>)}

</div>

    );
};

export default DumpingAreaTable;
