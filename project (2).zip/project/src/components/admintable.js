import React, { useState, useEffect } from "react";

const TableComponent = () => {
  const [tableData, setTableData] = useState([]);

  useEffect(() => {
    // Fetch table data from the API
    fetch('http://localhost:5000/api/getAdminData') // Replace with the appropriate API endpoint
      .then((response) => response.json())
      .then((data) => {
        setTableData(data);
      })
      .catch((error) => {
        console.error('Error fetching table data:', error);
      });
  }, []);

  return (
    <div className="card">
  <div className="card-body">
    <h1 className="my-4" style={{ textAlign: 'center' }}>
      Admin Table
    </h1>
    <table className="table table-striped table-bordered">
      <thead>
        <tr>
          <th>AdminID</th>
          <th>Username</th>
          <th>FirstName</th>
          <th>LastName</th>
          <th>Email</th>
          <th>MobileNumber</th>
          <th>Address</th>
          <th>City</th>
          <th>State</th>
          <th>Country</th>
          <th>PostalCode</th>
          <th>Rolee</th>
          <th>AccountStatus</th>
        </tr>
      </thead>
      <tbody>
        {tableData.map((row) => (
          <tr key={row.AdminID}>
            <td>{row.AdminID}</td>
            <td>{row.Username}</td>
            <td>{row.FirstName}</td>
            <td>{row.LastName}</td>
            <td>{row.Email}</td>
            <td>{row.MobileNumber}</td>
            <td>{row.Address}</td>
            <td>{row.City}</td>
            <td>{row.State}</td>
            <td>{row.Country}</td>
            <td>{row.PostalCode}</td>
            <td>{row.Role}</td>
            <td>{row.AccountStatus}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
</div>

  );
};

export default TableComponent;
