import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from 'react-router-dom';

const Login = ({ setToken }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    if (!email || !password) {
      setErrorMessage('Username and password are required');
      return;
    }

    try {
      // Make API request to your backend for authentication
      const role = document.getElementsByName("UserRole")[0].value;
      const response = await fetch('http://localhost:5000/login', {
        method: 'POST',
        headers: {


          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password, role }),
      });

      if (response.ok) {
        const data = await response.json();
        setToken(data.token);
        // localStorage.setItem('authToken', data.token);
        if (role === 'admin') {
          localStorage.setItem('adminAuthToken', data.token);
          navigate('/adminDashboard'); // Replace with your admin dashboard route
        } else if (role === 'user') {
          localStorage.setItem('userAuthToken', data.token);
          navigate('/userDashboard'); // Replace with your user dashboard route
        }
      } else {
        setErrorMessage('Invalid credentials');
      }
    } catch (error) {
      console.error('An error occurred:', error);
    }
  };




  return (
    <div className="d-flex justify-content-center align-items-center vh-100">
      <div>
   
   </div>
      <div className="card w-75 mb-3" id="maindiv">
      
        <div className="card-body">
        <h1 className="mb-3" style={{textAlign:"center"}}>Welcome to Sign-In Page</h1>
          {/* Sign-In Form */}
          <div className="mb-3 row">
            <label htmlFor="inputEmail" className="col-sm-2 col-form-label">
              Email
            </label>
            <div className="col-sm-10">
            <input
        type="text"
        placeholder="Username"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
            </div>
          </div>
          <div className="mb-3 row">
            <label htmlFor="inputPassword" className="col-sm-2 col-form-label">
              Password
            </label>
            <div className="col-sm-10">
            <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
            </div>
          </div>
          <div className="mb-3 row">
            <label className="col-sm-2 col-form-label">User Role</label>
            <div className="col-sm-10">
              <select name="UserRole">
                <option value="user">User</option>
                <option value="admin">Admin</option>
              </select>
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <button type="submit" className="btn btn-primary" onClick={handleLogin}>
              Submit
              </button>
            <button className="btn btn-primary">
              <Link
                to="/register"
                style={{ color: "white", textDecoration: "none" }}
              >
                New Registration
              </Link>
            </button>
          </div>
          {errorMessage && <p className="text-danger">{errorMessage}</p>} {/* Display error message */}
        </div>
      </div>
    </div>
  );
}
export default  Login;
