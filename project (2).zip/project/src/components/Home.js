import React from "react";
import "./Home.css";


// export default function Home=() {
  const Home=()=>{
    

  return (<div >
    {/* <h1 className="mx-auto" style={{textAlign:'center'}}>Welcome to the home page</h1> */}
    <body >
     
    <div className="homeClass" >
         <iframe name="iframe" frameborder="0"  src="about:blank"></iframe>
          
        </div>

      

       <div class="d-flex justify-content-center align-items-left " style={{height:'200px',background:'lightskyblue'}}>
        <ul style={{textAlign:'left'}}>
          <li>
            <p>contact : 9026709242</p>
         </li>
          <li>
          <p>Email : wastecomplaint@gmail.com</p>
          </li>
          <li>
          <p>address : Bengaluru,India</p>
          </li>
        </ul>
      </div>
    </body>
    
    </div>
  );
}
export default Home;
