import React, { useState, useEffect } from 'react';

const RecyclingAreaTable = () => {
  const [aauthToken, setAuthToken] = useState(null); // Example state to hold admin's auth token

    // Assume you're setting the admin's auth token using some method
    useEffect(() => {
        const adminToken = localStorage.getItem("adminAuthToken"); // Replace with your method to get admin's auth token
        setAuthToken(adminToken);
    }, []);
    const [recyclingAreas, setRecyclingAreas] = useState([]);
    const [newRecyclingArea, setNewRecyclingArea] = useState({
        location_name: '',
        address: '',
        city: '',
        state: '',
        country: '',
        postal_code: '',
        latitude: '',
        longitude: '',
        capacity: '',
        status: 'active',
        recycling_type: 'plastic',
    });

    useEffect(() => {
        fetchRecyclingAreas();
    }, []);

    const fetchRecyclingAreas = async () => {
        try {
            const response = await fetch('http://localhost:5000/api/getRecyclingAreas'); // Replace with your API endpoint
            const data = await response.json();
            setRecyclingAreas(data);
        } catch (error) {
            console.error('Error fetching recycling areas:', error);
        }
    };

    const handleAddRecyclingArea = async () => {
        try {
            const response = await fetch('http://localhost:5000/api/addRecyclingArea', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newRecyclingArea),
            });

            if (response.ok) {
                const newRecyclingAreas = [...recyclingAreas, newRecyclingArea];
                setRecyclingAreas(newRecyclingAreas);
                setNewRecyclingArea({
                    location_name: '',
                    address: '',
                    city: '',
                    state: '',
                    country: '',
                    postal_code: '',
                    latitude: '',
                    longitude: '',
                    capacity: '',
                    status: 'active',
                    recycling_type: 'plastic',
                });
            }
        } catch (error) {
            console.error('Error adding recycling area:', error);
        }
    };

    return (
        <div>
  <h2>Recycling Areas</h2>
  <table className="table table-striped table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>Location Name</th>
        <th>Address</th>
        <th>City</th>
        <th>State</th>
        <th>Country</th>
        <th>Postal Code</th>
        <th>Latitude</th>
        <th>Longitude</th>
        <th>Capacity</th>
        <th>Status</th>
        <th>Recycling Type</th>
      </tr>
    </thead>
    <tbody>
      {recyclingAreas.map((recyclingArea) => (
        <tr key={recyclingArea.id}>
          <td>{recyclingArea.id}</td>
          <td>{recyclingArea.location_name}</td>
          <td>{recyclingArea.address}</td>
          <td>{recyclingArea.city}</td>
          <td>{recyclingArea.state}</td>
          <td>{recyclingArea.country}</td>
          <td>{recyclingArea.postal_code}</td>
          <td>{recyclingArea.latitude}</td>
          <td>{recyclingArea.longitude}</td>
          <td>{recyclingArea.capacity}</td>
          <td>{recyclingArea.status}</td>
          <td>{recyclingArea.recycling_type}</td>
        </tr>
      ))}
    </tbody>
  </table>
  {aauthToken && (<div >
  
  <h2>Add New Recycling Area</h2>
  <div>
    <input
      className="form-control"
      type="text"
      placeholder="Location Name"
      value={newRecyclingArea.location_name}
      onChange={(e) =>
        setNewRecyclingArea({ ...newRecyclingArea, location_name: e.target.value })
      }
    />
    <input
      className="form-control"
      type="text"
      placeholder="Address"
      value={newRecyclingArea.address}
      onChange={(e) =>
        setNewRecyclingArea({ ...newRecyclingArea, address: e.target.value })
      }
    />
    <input
      className="form-control"
      type="text"
      placeholder="City"
      value={newRecyclingArea.city}
      onChange={(e) =>
        setNewRecyclingArea({ ...newRecyclingArea, city: e.target.value })
      }
    />
    <input
      className="form-control"
      type="text"
      placeholder="State"
      value={newRecyclingArea.state}
      onChange={(e) =>
        setNewRecyclingArea({ ...newRecyclingArea, state: e.target.value })
      }
    />
    <input
      className="form-control"
      type="text"
      placeholder="Country"
      value={newRecyclingArea.country}
      onChange={(e) =>
        setNewRecyclingArea({ ...newRecyclingArea, country: e.target.value })
      }
    />
    <input
      className="form-control"
      type="text"
      placeholder="Postal Code"
      value={newRecyclingArea.postal_code}
      onChange={(e) =>
        setNewRecyclingArea({ ...newRecyclingArea, postal_code: e.target.value })
      }
    />
    <input
      className="form-control"
      type="number"
      placeholder="Latitude"
      value={newRecyclingArea.latitude}
      onChange={(e) =>
        setNewRecyclingArea({ ...newRecyclingArea, latitude: e.target.value })
      }
    />
    <input
      className="form-control"
      type="number"
      placeholder="Longitude"
      value={newRecyclingArea.longitude}
      onChange={(e) =>
        setNewRecyclingArea({ ...newRecyclingArea, longitude: e.target.value })
      }
    />
    <input
      className="form-control"
      type="number"
      placeholder="Capacity"
      value={newRecyclingArea.capacity}
      onChange={(e) =>
        setNewRecyclingArea({ ...newRecyclingArea, capacity: e.target.value })
      }
    />
   <select
      className="form-control"
      value={newRecyclingArea.status}
      onChange={(e) =>
        setNewRecyclingArea({ ...newRecyclingArea, status: e.target.value })
      }
    >
      <option value="active">Active</option>
      <option value="inactive">Inactive</option>
    </select>
    <select
      className="form-control"
      value={newRecyclingArea.recycling_type}
      onChange={(e) =>
        setNewRecyclingArea({ ...newRecyclingArea, recycling_type: e.target.value })
      }
    >
      <option value="plastic">Plastic</option>
      <option value="paper">Paper</option>
      <option value="metal">Metal</option>
      <option value="glass">Glass</option>
      <option value="other">Other</option>
    </select>
    <button className="btn btn-primary" onClick={handleAddRecyclingArea}>
      Add
    </button>
  </div>
  </div>
)}

</div>

    );
};

export default RecyclingAreaTable;
