import React, { useState, useEffect } from 'react';

const ComplaintsTable = () => {
    const [complaints, setComplaints] = useState([]);

    useEffect(() => {
        fetchComplaints();
    }, []);

    const fetchComplaints = async () => {
        try {
            const response = await fetch('http://localhost:5000/api/getComplaints');
            const data = await response.json();
            setComplaints(data);
            console.log(data);
        } catch (error) {
            console.error('Error fetching complaints:', error);
        }
    };

    const handleStatusChange = async (complaintId, newStatus) => {
        try {
            const response = await fetch(`/api/updateComplaintStatus/${complaintId}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ status: newStatus }),
            });

            if (response.ok) {
                const updatedComplaints = complaints.map((complaint) => {
                    if (complaint.id === complaintId) {
                        return { ...complaint, status: newStatus };
                    }
                    return complaint;
                });
                setComplaints(updatedComplaints);
            }
        } catch (error) {
            console.error('Error updating complaint status:', error);
        }
    };

    return (
        <div>
        <h2>Complaints</h2>
        <table className="table table-bordered table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>User ID</th>
              <th>Email</th>
              <th>Request Text</th>
              <th>Status</th>
              <th>Update Status</th>
            </tr>
          </thead>
          <tbody>
            {complaints.map((complaint) => (
              <tr key={complaint.id}>
                <td>{complaint.id}</td>
                <td>{complaint.UserID}</td>
                <td>{complaint.Email}</td>
                <td>{complaint.requestText}</td>
                <td>{complaint.status}</td>
                <td>
                  <select
                    className="form-control"
                    value={complaint.status}
                    onChange={(e) => handleStatusChange(complaint.id, e.target.value)}
                  >
                    <option value="pending">Pending</option>
                    <option value="approve">Approved</option>
                    <option value="completed">Completed</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
    );
};

export default ComplaintsTable;
