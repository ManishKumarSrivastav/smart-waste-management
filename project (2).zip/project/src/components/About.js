import React from 'react';

const About = () => {
  return (
    <div className="card w-75 mb-3" target="ifarame" >
        <div >
      
        <h2>Why Smart Waste Management Required</h2>
        <p>
          Smart waste management refers to the integration of modern
          technologies and data-driven solutions to optimize the collection,
          disposal, and recycling of waste materials in urban environments.
          Traditional waste management systems often face challenges such as
          inefficient collection routes, overflowing bins, and environmental
          impact. Smart waste management addresses these issues by leveraging
          technology to create more sustainable and efficient waste management
          processes.
        </p>
        <p><h5>Key features of smart waste management include:</h5></p>
        <ul>
          
          <li>
            Real-time Notifications: Alerts about collection schedules and
            recycling tips via apps.
          </li>
          <li>
            Environmental Benefits: Reduced strain on landfills, lower
            pollution, and emissions.
          </li>
          <li>
            Cost Savings: Optimized routes, reduced labor costs, and emergency
            clean-up prevention.
          </li>
          <li>
            Public Participation: Citizen engagement for recycling campaigns and
            clean-up events.
          </li>
          <li>
            Waste Sorting and Recycling: Advanced technologies to separate and
            track recycling processes.
          </li>
          <li>Route Optimization: Using data from smart bins to dynamically optimize waste collection routes.</li>
          <li>
            Data Analytics: Insights into waste generation patterns for informed
            decision-making.
          </li>
          
          <li>Scalability: Customizable solutions for various urban areas.</li>
        </ul>
        <p>
          In essence, smart waste management harnesses the power of technology,
          data, and citizen engagement to create a more efficient, sustainable,
          and environmentally friendly waste management ecosystem. By optimizing
          waste collection, reducing environmental impact, and promoting
          recycling, these systems contribute to healthier and more livable
          cities.
        </p>
      </div>
      </div>
  );
};

export default About;
