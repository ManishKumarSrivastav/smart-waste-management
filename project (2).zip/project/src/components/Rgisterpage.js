import React, { useState } from "react";
import { Link } from "react-router-dom";

const RegistrationForm = () => {
  const [formData, setFormData] = useState({
    Username: "",
    Password: "",
    FirstName: "",
    LastName: "",
    Email: "",
    MobileNumber: "",
    Address: "",
    City: "",
    State: "",
    Country: "",
    PostalCode: "",
    EmployeeCode: "",
  });
  const [registrationStatus, setRegistrationStatus] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost:5000/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const data = await response.json();
        setRegistrationStatus('success');
        console.log("Registration successful:", data);
        // Perform any desired actions upon successful registration
      } else {
        setRegistrationStatus('error');
        console.log("Registration failed:", response.statusText);
        // Handle registration failure, e.g., show error message
      }
    } catch (error) {
      setRegistrationStatus('error');
      console.error("Error registering user/admin:", error);
    }
  };

  return (
    <div className="card" id="maindiv">
      <div className="card-body">
        <h1 className="my-4">Registration Form</h1>
        <div className="row">
          <div className="col-md-6">
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label"> Role</label>
                <select
                  className="form-select"
                  name="Role"
                  value={formData.Role}
                  onChange={handleInputChange}
                  required
                >
                  <option value="user">user</option>
                  <option value="admin">Admin</option>
                </select>
              </div>

              {formData.Role === "admin" && (
                <div className="mb-3">
                  <label className="form-label">Employee Code</label>
                  <input
                    type="text"
                    className="form-control"
                    name="EmployeeCode"
                    value={formData.EmployeeCode}
                    onChange={handleInputChange}
                    required={formData.Role === "admin"}
                  />
                </div>
              )}

              <div className="mb-3">
                <label className="form-label">First Name</label>
                <input
                  type="text"
                  className="form-control"
                  name="FirstName"
                  value={formData.FirstName}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Last Name</label>
                <input
                  type="text"
                  className="form-control"
                  name="LastName"
                  value={formData.LastName}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Email</label>
                <input
                  type="email"
                  className="form-control"
                  name="Email"
                  value={formData.Email}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Mobile Number</label>
                <input
                  type="tel"
                  className="form-control"
                  name="MobileNumber"
                  value={formData.MobileNumber}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Address</label>
                <input
                  type="text"
                  className="form-control"
                  name="Address"
                  value={formData.Address}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">City</label>
                <input
                  type="text"
                  className="form-control"
                  name="City"
                  value={formData.City}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">State</label>
                <input
                  type="text"
                  className="form-control"
                  name="State"
                  value={formData.State}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Country</label>
                <input
                  type="text"
                  className="form-control"
                  name="Country"
                  value={formData.Country}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Postal Code</label>
                <input
                  type="text"
                  className="form-control"
                  name="PostalCode"
                  value={formData.PostalCode}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label className="form-label">User Name</label>
                <input
                  type="text"
                  className="form-control"
                  name="Username"
                  value={formData.Username}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Password</label>
                <input
                  type="text"
                  className="form-control"
                  name="Password"
                  value={formData.Password}
                  onChange={handleInputChange}
                  required
                />
              </div>
              {registrationStatus === "success" && (
                <div className="alert alert-success mt-3">
                  Registration successful! You can now log in.
                </div>
              )}
              {registrationStatus === "error" && (
                <div className="alert alert-danger mt-3">
                  Registration failed. Please try again.
                </div>
              )}
              

              <div style={{ display: "flex", justifyContent: "space-between" }}> 
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
                <button className="btn btn-primary">
              <Link
                to="/login"
                style={{ color: "white", textDecoration: "none" }}
              >
               SignIn
              </Link>
            </button>
              </div>
            </form>
          </div>
        </div>

      </div>
    </div>
  );
};

export default RegistrationForm;
