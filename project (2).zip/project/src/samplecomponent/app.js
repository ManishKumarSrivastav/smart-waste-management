import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Login from './login';
import ProtectedPage from './protectedPage';

const App = () => {
  const [token, setToken] = useState(null);

  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={<Login setToken={setToken} />} // Pass setToken to the Login component
        />
        <Route
          path="/protected"
          element={token ? <ProtectedPage /> : <Navigate to="/" />}
        />
      </Routes>
    </Router>
  );
};

export default App;
