import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import jwt_decode from "jwt-decode"; // Import the JWT decoding library

const ComplaintForm = () => {
  const [complaint, setComplaint] = useState("");
  const [uploadedImage, setUploadedImage] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const authToken = localStorage.getItem("userAuthToken");
    console.log("authToken:", authToken);
    if (!authToken) {
      navigate("/login");
    } else {
      // Decode the JWT to get user information
      const decodedToken = jwt_decode(authToken);

      // Get the user's email from decoded token
      const userEmail = decodedToken.email;

      // Set the user's email in the complaint state
      setComplaint(userEmail);
    }
  }, []);
  // Empty dependency array

  const handleComplaintChange = (e) => {
    setComplaint(e.target.value);
  };

  const handleImageUpload = (acceptedFiles) => {
    const uploadedFile = acceptedFiles[0];
    setUploadedImage(uploadedFile);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Here you can perform actions like submitting the complaint and uploaded image to a backend server.
    // Example: send complaint text and image to an API using fetch or axios.

    // Reset the form fields after submission
    setComplaint("");
    setUploadedImage(null);
  };

  return (
    <div className="container mt-5">
      <h1 className="mb-4">Complaint Registration</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="complaint">Complaint:</label>
          <textarea
            id="complaint"
            className="form-control"
            value={complaint}
            onChange={handleComplaintChange}
            rows="4"
          />
        </div>
        {/* <div className="form-group">
          <label>Upload Image:</label>
          <Dropzone onDrop={handleImageUpload} accept="image/*" multiple={true}>
            {({ getRootProps, getInputProps }) => (
              <div className="dropzone border p-4 rounded" {...getRootProps()}>
                <input {...getInputProps()} />
                <p className="text-center mb-0">
                  Drag and drop an image here, or click to select one.
                </p>
                {uploadedImage && (
                  <img
                    src={URL.createObjectURL(uploadedImage)}
                    alt="Uploaded"
                    className="img-thumbnail mt-3"
                  />
                )}
              </div>
            )}
          </Dropzone>
        </div> */}

        <button type="submit" className="btn btn-primary">
          Submit
        </button>
      </form>
    </div>
  );
};

export default ComplaintForm;
