import React, { useState, useEffect } from 'react';

const TableUserComponent = () => {
  const [tableData, setTableData] = useState([]);

  useEffect(() => {
    // Fetch data from the API endpoint
    fetch('http://localhost:5000/api/getuserData') // Replace with your API endpoint and role
      .then(response => response.json())
      .then(data => {
        setTableData(data);
        console.log(data);
      })
      .catch(error => {
        console.error('Error fetching table data:', error);
      });
  }, []);

  return (
    <div className="card">
  <div className="card-body">
    <h1 className="my-4" style={{ textAlign: 'center' }}>
      User Table
    </h1>
    <table className="table table-striped table-bordered">
      <thead>
        <tr>
          <th>Username</th>
          <th>Password</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>Mobile Number</th>
          <th>Address</th>
          <th>City</th>
          <th>State</th>
          <th>Country</th>
          <th>Postal Code</th>
          <th>Role</th>
          <th>Account Status</th>
        </tr>
      </thead>
      <tbody>
        {tableData.map((row) => (
          <tr key={row.id}>
            <td>{row.Username}</td>
            <td>{row.Password}</td>
            <td>{row.FirstName}</td>
            <td>{row.LastName}</td>
            <td>{row.Email}</td>
            <td>{row.MobileNumber}</td>
            <td>{row.Address}</td>
            <td>{row.City}</td>
            <td>{row.State}</td>
            <td>{row.Country}</td>
            <td>{row.PostalCode}</td>
            <td>{row.Rolee}</td>
            <td>{row.AccountStatus}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
</div>

  );
};

export default TableUserComponent;
