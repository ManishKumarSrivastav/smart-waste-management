import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom"; // If you're using React Router
// import About from "./components/About";
import About from "./components/About";

export default function Navbar(props) {
  const [activeContent, setActiveContent] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const userAuthtoken = localStorage.getItem("userAuthToken");
  const adminAuthtoken = localStorage.getItem("adminAuthToken");
  useEffect(() => {
    if (userAuthtoken) {
      setIsLoggedIn(true);
    } else if (adminAuthtoken) {
      setIsLoggedIn(true);
    }
  }, []);

  const handlelogout = () => {
    if (userAuthtoken) {
      localStorage.removeItem("userAuthToken");
      setIsLoggedIn(false);
      return;
    } else if (adminAuthtoken) {
      localStorage.removeItem("adminAuthToken");
      setIsLoggedIn(false);
    }
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid">
          <a className="navbar-brand" href="/">
            {props.home}
          </a>

          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarScroll"
            aria-controls="navbarScroll"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarScroll">
            <ul className="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll">
              <li className="nav-item dropdown">
                <a
                  className="nav-link dropdown-toggle"
                  href="/"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  {props.about}
                </a>
                <ul className="dropdown-menu">
                  <li>
                    <Link
                      className="dropdown-item"
                      onClick={() => setActiveContent("about")}
                       
                    >
                      About
                    </Link>
                  </li>

                  {/* <li>
                    <a
                      className="dropdown-item"
                      onClick={() => setActiveContent("about")}
                    target="ifarame"
                    >
                      why this
                    </a>
                  </li> */}
                </ul>
              </li>

              <li className="nav-item dropdown">
                <a
                  className="nav-link dropdown-toggle"
                  href="/"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  {props.soln}
                </a>
                <ul className="dropdown-menu">
                  <li>
                    <Link className="dropdown-item" to="/complaintpage">
                      register complaints
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/dumpingarea">
                      Dumping Area
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/recylingarea">
                      Recycling Area
                    </Link>
                  </li>
                </ul>
              </li>

              <li className="nav-item dropdown">
                <a
                  className="nav-link dropdown-toggle"
                  href="/"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  {props.future}
                </a>
                <ul className="dropdown-menu">
                  <li>
                    <Link className="dropdown-item" to="/">
                      Bin Sensor
                    </Link>
                  </li>
                  {/* <li>
                    <Link className="dropdown-item" to="/">
                      Geo Location through User
                    </Link>
                  </li> */}
                </ul>
              </li>

              <li className="nav-item">
                <a className="nav-link" href="/">
                  {props.contact}
                </a>
              </li>

              {isLoggedIn ? (
                <li className="nav-item">
                  <a
                    onClick={handlelogout}
                    className="nav-link active"
                    aria-current="page"
                    href="/logout"
                  >
                    {props.signout}
                  </a>
                </li>
              ) : (
                <li className="nav-item">
                  <a
                    className="nav-link active"
                    aria-current="page"
                    href="/login"
                  >
                    {props.signin}
                  </a>
                </li>
              )}
            </ul>
          </div>
        </div>
      </nav>
      {activeContent === "about" && < About />}
    </div>
  );
}
